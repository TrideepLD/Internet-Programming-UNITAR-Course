<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="Assignmentcss.css">
</head>
<body>
<div class="container">  
  <form id="contact" action="educational_background.php" method="post">
    <h3>University X Regristration Form</h3>
    <fieldset>
      <input placeholder="Your phone Contact" type="tel" tabindex="3" required name="emergency">
    </fieldset>
    <fieldset>
    <input placeholder="Your Email Address" type="email" tabindex="2" required name="email">
    </fieldset>
    <fieldset>
      <input placeholder="Your Emergency Contact" type="tel" tabindex="3" required name="emergency">
    </fieldset>
    <fieldset>
      <textarea placeholder="Type your Message Here...." tabindex="5" required name="message"></textarea>
    </fieldset>
    <fieldset>
      <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Submit</button>
    </fieldset>
    <fieldset>
      <button name="reset" type="reset" id="contact-submit" data-submit="...Sending">Clear</button>
    </fieldset>
  </form>

 
  
</div>
</body>
