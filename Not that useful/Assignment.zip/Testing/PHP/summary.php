

<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="summarycss.css">
</head>
<body>
 <div id="wrapper">
  <h1>Summary</h1>
  
  <table id="keywords" cellspacing="0" cellpadding="0">

    <tbody>
      <tr>
        <td class="lalign">Full Name</td>
        <td>asdsa</td>
      </tr>
      <tr>
        <td class="lalign">Gender</td>
        <td></td>
      </tr>
      <tr>
        <td class="lalign">Date of Birth</td>
        <td></td>
      </tr>
      <tr>
        <td class="lalign">E-Mail</td>
        <td></td>
      </tr>
      <tr>
        <td class="lalign">Personal Contact</td>
        <td></td>
      </tr>
      <tr>
        <td class="lalign">Emergency Contact</td>
        <td></td>
      </tr>
      <tr>
        <td class="lalign">Highschool Qualification</td>
        <td></td>
      </tr>
      <tr>
        <td class="lalign">Pre-University Qualification</td>
        <td></td>
      </tr>
      <tr>
        <td class="lalign">Undergraduate Qualification</td>
        <td></td>
      </tr>
    </tbody>
  </table>
 </div> 
</body>
</html>